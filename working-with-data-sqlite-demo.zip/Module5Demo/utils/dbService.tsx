import {openDatabase} from 'react-native-sqlite-storage';

const db = openDatabase({name: 'little_lemon', location: 'default'});

export async function createTable() {
  return new Promise(async (resolve, reject) => {
    (await db).transaction(
      tx => {
        console.log('inside transaction of create table');
        tx.executeSql(
          'create table if not exists menuitems (id integer primary key not null, uuid text, title text, price text, category text);',
        );
      },
      reject,
      resolve,
    );
  });
}

export async function getMenuItems() {
  return new Promise<any[]>(async (resolve, reject) => {
    (await db).transaction(tx => {
      tx.executeSql(
        'select * from menuitems',
        [],
        (_, {rows}) => {
          let data_array = [];
          for (let i = 0; i < rows.length; i++) {
            data_array.push(rows.item(i));
          }
          resolve(data_array);
        },
        (_, error) => {
          reject(error);
          console.log('error in get menu items :: ', error);
          return true;
        },
      );
    });
  });
}

export async function saveMenuItems(
  menuItems: {
    id: number;
    price: string;
    title: string;
    category: {title: string};
  }[],
) {
  console.log('data in save menu items :: ', menuItems);
  (await db).transaction(tx => {
    menuItems.forEach(ele => {
      const query =
        'INSERT INTO menuitems (id, uuid, title, price, category) VALUES (?, ?, ?, ?, ?)';
      tx.executeSql(
        query,
        [ele?.id, ele?.id, ele?.title, ele?.price, ele?.category?.title],
        (_, {rows}) => {
          console.log('Status : Success');
        },
        err => {
          console.log('inside foe each :: ', ele);
          console.log('Status : Failed', err);
        },
      );
    });
  });
}

export async function filterByQueryAndCategories(
  query: string,
  activeCategories: any[],
) {
  //   return activeCategories;
  return new Promise<any[]>(async (resolve, reject) => {
    (await db).transaction(tx => {
      const result: any = [];
      let qStr = '?';
      activeCategories.forEach(ele => {
        qStr += ', ?';
      });
      tx.executeSql(
        'select * from menuitems where category IN (' + qStr + ')',
        [...activeCategories],
        (_, {rows}) => {
          console.log('rows :: ', rows);
          for (let i = 0; i < rows.length; i++) {
            if (
              rows.item(i).title.toLowerCase().includes(query.toLowerCase())
            ) {
              result.push(rows.item(i));
            }
          }

          //   rows._array.forEach((ele: {title: string}) => {
          //     if (ele.title.toLowerCase().includes(query.toLowerCase())) {
          //       result.push(ele);
          //     }
          //   });
          resolve(result);
        },
        err => {
          reject(err);
        },
      );
    });
  });
}
