interface IData {
  id: any;
  title: any;
  price: any;
}

export interface ISectionData {
  title: any;
  data: IData[];
}

export function getSectionListData(data: any[]) {
  const mocData: ISectionData[] = [];
  data.forEach(ele => {
    let isMatched = false;
    mocData.forEach(ele1 => {
      if (ele1.title == ele.category) {
        ele1.data = [
          ...ele1.data,
          {
            id: ele.id,
            title: ele.title,
            price: ele.price,
          },
        ];
        isMatched = true;
      }
    });
    if (!isMatched) {
      mocData.push({
        title: ele.category,
        data: [{id: ele.id, title: ele.title, price: ele.price}],
      });
    }
  });
  return mocData;
}
