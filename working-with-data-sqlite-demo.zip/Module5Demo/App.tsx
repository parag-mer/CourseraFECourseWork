/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React, {useEffect, useState} from 'react';
import {
  Button,
  SafeAreaView,
  SectionList,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {fetchData} from './utils/fetchData';
import {
  createTable,
  filterByQueryAndCategories,
  getMenuItems,
  saveMenuItems,
} from './utils/dbService';
import {ISectionData, getSectionListData} from './utils/sectionListMaker';
import {SectionItem} from './utils/SectionItem';

const App = () => {
  const [sections, setSections] = useState([
    {name: 'Appetizers', selected: false},
    {name: 'Salads', selected: false},
    {name: 'Beverages', selected: false},
  ]);
  const [search, setSearch] = useState('');
  const [sectionListData, setSectionListData] = useState<ISectionData[]>([]);

  const onFilterSelect = (index: number) => {
    const newSelection = [...sections];
    newSelection[index].selected = !newSelection[index].selected;
    setSections(newSelection);
  };

  const dataGetter = async () => {
    try {
      console.log('in try block');
      await createTable();
      let dbData = await getMenuItems();
      console.log('dbData', dbData);
      if (!dbData.length) {
        let data = await fetchData();
        await saveMenuItems(data);
        dbData = await getMenuItems();
      }
      const data = await getSectionListData(dbData);
      console.log('data after getSectionListData :: ', data);
      setSectionListData(data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    dataGetter();
  }, []);

  const categorySelector = async () => {
    let activeCategories = sections.filter(section => section.selected);

    if (activeCategories.length == 0) {
      activeCategories = sections;
    }
    const selected = activeCategories.map(a => a.name);
    console.log('selected', selected);

    try {
      const menuItems = await filterByQueryAndCategories(search, selected);
      setSectionListData(menuItems);
      console.log('menuItems :: ', menuItems);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    categorySelector();
  }, [sections]);

  return (
    <SafeAreaView style={styles.container}>
      <View
        style={{paddingHorizontal: 10, backgroundColor: '#495E57', flex: 1}}>
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder="Search"
          style={styles.searchField}
        />
        <View style={styles.filtersContainer}>
          {sections.map((section, index) => (
            <TouchableOpacity
              style={[
                styles.filterBtn,
                {backgroundColor: section.selected ? '#EE9972' : '#495E57'},
              ]}
              onPress={() => onFilterSelect(index)}>
              <Text style={styles.filterBtnText}>{section.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <SectionList
          sections={sectionListData}
          renderItem={({item}) => (
            <SectionItem title={item.title} price={item.price} key={item.id} />
          )}
          renderSectionHeader={({section: {title}}) => (
            <Text style={styles.header}>{title}</Text>
          )}
        />
      </View>
    </SafeAreaView>
  );
};

export default App;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'flex-start',
  },
  searchField: {
    height: 50,
    width: '100%',
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 10,
    marginVertical: 10,
    paddingHorizontal: 10,
  },
  filtersContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 10,
  },
  filterBtn: {
    borderColor: '#fff',
    borderWidth: 1,
    paddingHorizontal: 10,
    paddingVertical: 5,
    width: '33.5%',
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  filterBtnText: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  header: {
    fontSize: 24,
    paddingVertical: 8,
    color: '#FBDABB',
    backgroundColor: '#495E57',
  },
});
